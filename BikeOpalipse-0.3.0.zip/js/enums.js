var DeathCause = {
	HOLE: 1,
	FIRE: 2,
	CHASERS: 3
};
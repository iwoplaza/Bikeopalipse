function GameModeStory() {
    GameMode.call(this);
}
GameModeStory.prototype = Object.create(GameMode.prototype);
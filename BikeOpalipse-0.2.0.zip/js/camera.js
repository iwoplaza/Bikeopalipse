var Camera = {
	scale: 2,
	
	
};